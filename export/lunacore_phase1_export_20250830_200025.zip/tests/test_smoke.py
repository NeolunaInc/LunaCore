def test_math_works():
    assert 1 + 1 == 2
