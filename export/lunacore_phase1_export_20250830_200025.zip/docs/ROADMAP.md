
Roadmap LunaCore
Vue synthétique
PhaseTitre (extrait)StatutNotes
0Bootstrap & socle d’ingénierieBacklog
1Orchestrator minimal /healthz (FastAPI)TerminéEndpoint + test httpx + run-api
6ExecutionOrchestrator v1Backlog
18Packaging & DeliveryBacklog
19CI/CD & EnvironnementsBacklog
21Orchestrator v2 (Parallélisme)Backlog
22External Agent PluginBacklog
23CreativeEnhancementAgentBacklog
24Observabilité & métriquesBacklog
25SLOs, KPIs & CostingBacklog
26Durcissement Production & GouvernanceBacklog

La liste complète et l’ordre sont pilotés dans le GitHub Project via le champ PhaseNo + tri ascendant.

Prochaine étape (Phase 2 — squelette services)
Squelette services/ avec interface d’appel modèle (via OLLAMA_BASE_URL).

Endpoint /v1/generate (stub) + test d’intégration.

Journalisation corrélée (trace_id) et réponses JSON standardisées.
